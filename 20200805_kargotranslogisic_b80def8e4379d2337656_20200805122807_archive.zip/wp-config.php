<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', '' );


/** Имя пользователя MySQL */
define( 'DB_USER', '' );


/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );


/** Имя сервера MySQL */
define( 'DB_HOST', '' );


/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );


/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Z7_:D^ xQ7>G)+k>4,)5#>kH7I]Qi)K,5fB2o*rDK/Im4Urw4Gjs/5xIQ8I$2@z:' );

define( 'SECURE_AUTH_KEY',  '([_e.loIj+}2kgX*SezB+GmSsQW/Lg*pJt_!34xr=~x z^a]zZnD8<VitF0AqJ?(' );

define( 'LOGGED_IN_KEY',    'O/.zF9|1?jRo/8@(;9^9iKNo$7n*Te[Xo:f|r2OsT8^}dDelefc19;_~gPe.gN:`' );

define( 'NONCE_KEY',        'XUGRrN0a|p4c<-tkQ+q5db;G7em%M{?g@iKA4BEg(ry?o}klGTy^^3s7iBsYyJ:h' );

define( 'AUTH_SALT',        '#2WYWwaQr@LC,9%cZ3ZdMC=3&p][(9][L.pQ..,.D$L[eEI*!O<4AP= :7sM?L^,' );

define( 'SECURE_AUTH_SALT', 'u&wley<BI>W{Bb<|Y?U+u8&nWv?w/5}l:[BH/;|zqje/Y]R7`s|}HBt!/hHk]W/]' );

define( 'LOGGED_IN_SALT',   'Yo:+?!aJ-ES/P3zV2]OP<8Ws1F?NFe]nG#vs.<BFVGhO!eu%[Z*E$;xJ^HPR3.bC' );

define( 'NONCE_SALT',       '}n{np!W6 ^6rX,+)8`rt&R039-YF2IKEG(r_`LUmET~Ms}io^E.DS~ApNrR>R`=K' );


/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'ktl_';


/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
